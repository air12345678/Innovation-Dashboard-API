let mysql = require('mysql');

let connection = mysql.createConnection({
    connectionLimit: 10,
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'jcg_schema'
});

// connect to the MySQL server
connection.connect(function(err) {
    if (err) {
      return console.error('error: ' + err.message);
    }
   
    let createPosts = `CREATE TABLE IF NOT EXISTS Posts (
                            id INT PRIMARY KEY,
                            title VARCHAR(64) NOT NULL,
                            author_id INT NOT NULL
                        )`;
   
    connection.query(createPosts, function(err, results, fields) {
      if (err) {
        console.log(err.message);
      }
    });
   
    connection.end(function(err) {
      if (err) {
        return console.log(err.message);
      }
    });
  });