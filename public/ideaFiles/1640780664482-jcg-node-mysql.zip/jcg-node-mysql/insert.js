let mysql = require('mysql');

let connection = mysql.createConnection({
    connectionLimit: 10,
    host: 'localhost',
    user: 'root',
    password: 'root',
    database: 'jcg_schema'
});

let insertQuery = "INSERT INTO Posts VALUES (1, 'Introduction to Python', 23)";

// execute the insert query
connection.query(insertQuery);
connection.end();